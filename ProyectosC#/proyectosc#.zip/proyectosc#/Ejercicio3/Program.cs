﻿using System;

class Program
{
    static void Main()
    {
        int opcion;
        do
        {
            MostrarMenu();
            opcion = LeerEntero("Elige una opción: ");

            switch (opcion)
            {
                case 1: Sumar(); break;
                case 2: Restar(); break;
                case 3: Multiplicar(); break;
                case 4: Dividir(); break;
                case 5: RaizCuadrada(); break;
                case 6: Potencia(); break;
                case 7: ValorAbsoluto(); break;
                case 8: Maximo(); break;
                case 9: Minimo(); break;
                case 10: Console.WriteLine("¡Saliendo del programa!"); break;
                default: Console.WriteLine("Opción no válida."); break;
            }

            Console.WriteLine();
        } while (opcion != 10);
    }

    // ---- Funciones auxiliares ----
    static void MostrarMenu()
    {
        Console.WriteLine("===== MENÚ DE OPERACIONES =====");
        Console.WriteLine("1. Sumar");
        Console.WriteLine("2. Restar");
        Console.WriteLine("3. Multiplicar");
        Console.WriteLine("4. Dividir");
        Console.WriteLine("5. Raíz cuadrada");
        Console.WriteLine("6. Potencia");
        Console.WriteLine("7. Valor absoluto");
        Console.WriteLine("8. Máximo entre dos números");
        Console.WriteLine("9. Mínimo entre dos números");
        Console.WriteLine("10. Salir");
    }

    static int LeerEntero(string mensaje)
    {
        Console.Write(mensaje);
        return int.Parse(Console.ReadLine());
    }

    static double LeerDouble(string mensaje)
    {
        Console.Write(mensaje);
        return double.Parse(Console.ReadLine());
    }

    // ---- Funciones matemáticas ----
    static void Sumar()
    {
        double a = LeerDouble("Ingrese el primer número: ");
        double b = LeerDouble("Ingrese el segundo número: ");
        Console.WriteLine($"Resultado: {a + b}");
    }

    static void Restar()
    {
        double a = LeerDouble("Ingrese el primer número: ");
        double b = LeerDouble("Ingrese el segundo número: ");
        Console.WriteLine($"Resultado: {a - b}");
    }

    static void Multiplicar()
    {
        double a = LeerDouble("Ingrese el primer número: ");
        double b = LeerDouble("Ingrese el segundo número: ");
        Console.WriteLine($"Resultado: {a * b}");
    }

    static void Dividir()
    {
        double a = LeerDouble("Ingrese el dividendo: ");
        double b = LeerDouble("Ingrese el divisor: ");
        if (b == 0)
            Console.WriteLine("Error: No se puede dividir entre cero.");
        else
            Console.WriteLine($"Resultado: {a / b}");
    }

    static void RaizCuadrada()
    {
        double a = LeerDouble("Ingrese un número: ");
        if (a < 0)
            Console.WriteLine("Error: No se puede calcular la raíz cuadrada de un número negativo.");
        else
            Console.WriteLine($"Resultado: {Math.Sqrt(a)}");
    }

    static void Potencia()
    {
        double a = LeerDouble("Ingrese la base: ");
        double b = LeerDouble("Ingrese el exponente: ");
        Console.WriteLine($"Resultado: {Math.Pow(a, b)}");
    }

    static void ValorAbsoluto()
    {
        double a = LeerDouble("Ingrese un número: ");
        Console.WriteLine($"Resultado: {Math.Abs(a)}");
    }

    static void Maximo()
    {
        double a = LeerDouble("Ingrese el primer número: ");
        double b = LeerDouble("Ingrese el segundo número: ");
        Console.WriteLine($"El mayor es: {Math.Max(a, b)}");
    }

    static void Minimo()
    {
        double a = LeerDouble("Ingrese el primer número: ");
        double b = LeerDouble("Ingrese el segundo número: ");
        Console.WriteLine($"El menor es: {Math.Min(a, b)}");
    }
}
