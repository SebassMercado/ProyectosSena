﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int cantidadEstudiantes = 4;
        int cantidadNotas = 5;

        string[] nombres = new string[cantidadEstudiantes];
        double[,] notas = new double[cantidadEstudiantes, cantidadNotas];
        double[] promedios = new double[cantidadEstudiantes];

        
        for (int i = 0; i < cantidadEstudiantes; i++)
        {
            Console.Write($"Ingrese el nombre del estudiante #{i + 1}: ");
            nombres[i] = Console.ReadLine();

            double suma = 0;

            for (int j = 0; j < cantidadNotas; j++)
            {
                Console.Write($"Ingrese la calificación #{j + 1} de {nombres[i]} (0 a 100): ");
                double nota;

                
                while (!double.TryParse(Console.ReadLine(), out nota) || nota < 0 || nota > 100)
                {
                    Console.Write("Nota inválida. Ingrese una calificación entre 0 y 100: ");
                }

                notas[i, j] = nota;
                suma += nota;
            }

            
            Console.WriteLine(); 
        }

       
        Console.WriteLine("\nLIBRO DE CALIFICACIONES\n");
        Console.WriteLine("Estudiante\tNota1\tNota2\tNota3\tNota4\tNota5\tPromedio");

        for (int i = 0; i < cantidadEstudiantes; i++)
        {
            Console.Write($"{nombres[i]}\t");

            for (int j = 0; j < cantidadNotas; j++)
            {
                Console.Write($"{notas[i, j]}\t");
            }

            Console.WriteLine($"{promedios[i]:F2}");
        }
    }
}

