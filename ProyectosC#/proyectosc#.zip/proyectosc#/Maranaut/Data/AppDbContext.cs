// Archivo: Data/AppDbContext.cs
using Microsoft.EntityFrameworkCore;
using Maranaut.Models;

namespace Maranaut.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        // DbSets -> representan las tablas
        public DbSet<Usuario> Usuarios { get; set; } = null!;
        public DbSet<Viaje> Viajes { get; set; } = null!;
        public DbSet<Reserva> Reservas { get; set; } = null!;
        public DbSet<Pago> Pagos { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configuración de Usuario
            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.Property(u => u.Nombre)
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(u => u.Email)
                      .HasMaxLength(150)
                      .IsRequired();

                entity.Property(u => u.Contrasena)
                      .HasMaxLength(200) // más largo por si usas hash en futuro
                      .IsRequired();

                entity.Property(u => u.Rol)
                      .HasMaxLength(1) // "A" = Admin, "U" = Usuario
                      .IsRequired();
            });

            // Configuración de Viaje
            modelBuilder.Entity<Viaje>(entity =>
            {
                entity.Property(v => v.Destino)
                      .HasMaxLength(200)
                      .IsRequired();

                entity.Property(v => v.Precio)
                      .HasColumnType("decimal(18,2)");

                entity.Property(v => v.Fecha)
                      .HasColumnType("date"); // solo fecha, sin hora
            });

            // Configuración de Reserva
            modelBuilder.Entity<Reserva>(entity =>
            {
                entity.Property(r => r.FechaReserva)
                      .HasColumnType("date");

                entity.HasOne(r => r.Usuario)
                      .WithMany(u => u.Reservas)
                      .HasForeignKey(r => r.IdUsuario)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(r => r.Viaje)
                      .WithMany(v => v.Reservas)
                      .HasForeignKey(r => r.IdViaje)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // Configuración de Pago
            modelBuilder.Entity<Pago>(entity =>
            {
                entity.Property(p => p.MetodoPago)
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(p => p.Monto)
                      .HasColumnType("decimal(18,2)");

                entity.HasOne(p => p.Reserva)
                      .WithMany(r => r.Pagos)
                      .HasForeignKey(p => p.IdReserva)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // Seeding inicial: un administrador por defecto
            modelBuilder.Entity<Usuario>().HasData(
                new Usuario
                {
                    IdUsuario = 1,
                    Nombre = "Administrador",
                    Email = "admin@maranaut.com",
                    Contrasena = "123456", // ⚠️ en producción usar hashing
                    Rol = "A"
                }
            );
        }
    }
}
