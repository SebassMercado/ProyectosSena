using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Maranaut.Models
{
    public class Reserva
    {
        [Key]
        public int IdReserva { get; set; }

        public DateTime FechaReserva { get; set; } = DateTime.Now;  // Inicializado por defecto
        public string Estado { get; set; } = string.Empty;           // Inicializado

        // Relaciones
        public int IdUsuario { get; set; }
        public Usuario Usuario { get; set; } = null!;               // null! porque EF lo llenará

        public int IdViaje { get; set; }
        public Viaje Viaje { get; set; } = null!;                   // null! porque EF lo llenará

        public ICollection<Pago> Pagos { get; set; } = new List<Pago>();  // Inicializado
    }
}
