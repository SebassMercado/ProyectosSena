using System;
using System.ComponentModel.DataAnnotations;

namespace Maranaut.Models
{
    public class Pago
    {
        [Key]  // ✅ EF Core reconoce la clave primaria
        public int IdPago { get; set; }

        public decimal Monto { get; set; } = 0m;                  // Inicializado
        public DateTime FechaPago { get; set; } = DateTime.Now;   // Inicializado
        public string MetodoPago { get; set; } = string.Empty;    // Inicializado

        // Relaciones
        public int IdReserva { get; set; }
        public Reserva Reserva { get; set; } = null!;             // null! porque EF lo llenará
    }
}
