using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Maranaut.Models
{
    public class Viaje
    {
        [Key]
        public int IdViaje { get; set; }

        public string Destino { get; set; } = string.Empty;  // Inicializado
        public DateTime Fecha { get; set; } = DateTime.Now;  // Inicializado con fecha actual
        public decimal Precio { get; set; } = 0m;           // Inicializado con 0

        // Relaciones
        public ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();  // Inicializado
    }
}
