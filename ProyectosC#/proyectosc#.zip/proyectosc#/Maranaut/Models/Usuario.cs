using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace Maranaut.Models
{
    public class Usuario
    {
        [Key]
        public int IdUsuario { get; set; }

        [Required]
        public string Nombre { get; set; } = string.Empty;  // Inicializado

        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;   // Inicializado

        [Required]
        public string Contrasena { get; set; } = string.Empty;  // Inicializado

        // Rol: "A" = Administrador, "U" = Usuario normal
        [Required]
        [StringLength(1)]  // porque solo usaremos una letra (A/U)
        public string Rol { get; set; } = "U";  

        // Relaciones
        public ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();  // Inicializado
    }
}
