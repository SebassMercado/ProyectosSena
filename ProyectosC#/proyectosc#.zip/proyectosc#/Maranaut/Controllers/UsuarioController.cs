using Microsoft.AspNetCore.Mvc;
using Maranaut.Data;
using Maranaut.Models;
using System.Linq;

namespace Maranaut.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly AppDbContext _context;

        public UsuarioController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        public IActionResult Login(string email, string contrasena)
        {
            var usuario = _context.Usuarios
                .FirstOrDefault(u => u.Email == email && u.Contrasena == contrasena);

            if (usuario != null)
            {
                // Guardamos datos básicos en sesión
                HttpContext.Session.SetString("UsuarioNombre", usuario.Nombre);
                HttpContext.Session.SetString("UsuarioRol", usuario.Rol);

                if (usuario.Rol == "A")
                {
                    // 🚀 Redirige al CRUD de usuarios (vista en Views/Crud/Usuario.cshtml)
                    return RedirectToAction("Usuario", "Crud");
                }
                else
                {
                    // 🚀 Redirige a la página principal de usuario normal
                    return RedirectToAction("Index", "Home");
                }
            }

            TempData["Error"] = "Credenciales incorrectas";
            return RedirectToAction("Index", "Home");

        }
    }
}
