using Microsoft.AspNetCore.Mvc;
using Maranaut.Data;
using Maranaut.Models;
using System.Linq;

namespace Maranaut.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly AppDbContext _context;

        public UsuarioController(AppDbContext context)
        {
            _context = context;
        }

        // -----------------------
        // LOGIN
        // -----------------------
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string email, string contrasena)
        {
            var usuario = _context.Usuarios
                .FirstOrDefault(u => u.Email == email && u.Contrasena == contrasena);

            if (usuario != null)
            {
                HttpContext.Session.SetString("UsuarioNombre", usuario.Nombre);
                HttpContext.Session.SetString("UsuarioRol", usuario.Rol);

                if (usuario.Rol == "A")
                {
                    // Redirige al CRUD de usuarios
                    return RedirectToAction("Index");
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }

            TempData["Error"] = "Credenciales incorrectas";
            return RedirectToAction("Index", "Home");
        }

        // -----------------------
        // CRUD DE USUARIOS
        // -----------------------

        // LISTAR
        public IActionResult Index()
        {
            var usuarios = _context.Usuarios.ToList();
            // Vista singular Usuario.cshtml
            return View("~/Views/Crud/Usuario.cshtml", usuarios);
        }

        // CREAR
        [HttpPost]
        public IActionResult Crear(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                _context.Usuarios.Add(usuario);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        // EDITAR
        [HttpPost]
        public IActionResult Editar(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                _context.Usuarios.Update(usuario);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        // ELIMINAR
        public IActionResult Eliminar(int id)
        {
            var usuario = _context.Usuarios.Find(id);
            if (usuario != null)
            {
                _context.Usuarios.Remove(usuario);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public IActionResult CerrarSesion()
        {
            HttpContext.Session.Clear(); // Borra todas las variables de sesión
            return RedirectToAction("Index", "Home"); // Redirige a Home/Index
        }

    }
}
