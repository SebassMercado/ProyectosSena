using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Maranaut.Controllers
{
    public class CrudController : Controller
    {
        // Datos quemados (ejemplo de destinos turísticos)
        private static List<DestinoTuristico> destinos = new List<DestinoTuristico>
        {
            new DestinoTuristico { Id = 1, Nombre = "Cartagena", Pais = "Colombia", Descripcion = "Ciudad amurallada y playas hermosas" },
            new DestinoTuristico { Id = 2, Nombre = "París", Pais = "Francia", Descripcion = "La ciudad del amor y la Torre Eiffel" },
            new DestinoTuristico { Id = 3, Nombre = "Tokio", Pais = "Japón", Descripcion = "Tecnología, cultura y templos antiguos" }
        };

        public IActionResult Index()
        {
            return View(destinos);
        }
    }

    // Modelo simple para la tabla
    public class DestinoTuristico
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Pais { get; set; }
        public string Descripcion { get; set; }
    }
}
