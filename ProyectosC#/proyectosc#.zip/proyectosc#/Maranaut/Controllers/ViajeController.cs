using Microsoft.AspNetCore.Mvc;
using Maranaut.Data;
using Maranaut.Models;
using System.Linq;

namespace Maranaut.Controllers
{
    public class ViajeController : Controller
    {
        private readonly AppDbContext _context;

        public ViajeController(AppDbContext context)
        {
            _context = context;
        }

        // LISTAR
        public IActionResult Index()
        {
            var viajes = _context.Viajes.ToList();
            return View("~/Views/Crud/Viaje.cshtml", viajes);
        }

        // CREAR
        [HttpPost]
        public IActionResult Crear(Viaje viaje)
        {
            if (ModelState.IsValid)
            {
                _context.Viajes.Add(viaje);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        // EDITAR
        [HttpPost]
        public IActionResult Editar(Viaje viaje)
        {
            if (ModelState.IsValid)
            {
                _context.Viajes.Update(viaje);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        // ELIMINAR
        public IActionResult Eliminar(int id)
        {
            var viaje = _context.Viajes.Find(id);
            if (viaje != null)
            {
                _context.Viajes.Remove(viaje);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        // DETALLES (opcional)
        public IActionResult Details(int id)
        {
            var viaje = _context.Viajes.FirstOrDefault(v => v.IdViaje == id);
            if (viaje == null) return NotFound();
            return View(viaje);
        }
    }
}

