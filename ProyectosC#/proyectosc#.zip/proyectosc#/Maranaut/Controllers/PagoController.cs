// Archivo: Controllers/PagoController.cs
using Maranaut.Data;
using Maranaut.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Maranaut.Controllers
{
    public class PagoController : Controller
    {
        private readonly AppDbContext _context;

        public PagoController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Listar todos los pagos
        public async Task<IActionResult> Index()
        {
            var pagos = await _context.Pagos
                .Include(p => p.Reserva)
                .ThenInclude(r => r.Usuario) // Para mostrar usuario
                .Include(p => p.Reserva)
                .ThenInclude(r => r.Viaje)   // Para mostrar viaje
                .ToListAsync();

            ViewBag.Reservas = await _context.Reservas.ToListAsync(); // Dropdown en modal
            return View("~/Views/Crud/Pago.cshtml", pagos);
        }

        // POST: Crear pago
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Crear(Pago pago)
        {
            if (ModelState.IsValid)
            {
                _context.Pagos.Add(pago);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            // Si hay error, recargar reservas y regresar a la vista
            ViewBag.Reservas = await _context.Reservas.ToListAsync();
            var pagos = await _context.Pagos
                .Include(p => p.Reserva)
                .ThenInclude(r => r.Usuario)
                .Include(p => p.Reserva)
                .ThenInclude(r => r.Viaje)
                .ToListAsync();
            return View("~/Views/Crud/Pago.cshtml", pagos);
        }

        // POST: Editar pago
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Editar(Pago pago)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Pagos.Update(pago);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Pagos.Any(p => p.IdPago == pago.IdPago))
                        return NotFound();
                    else
                        throw;
                }
                return RedirectToAction(nameof(Index));
            }

            // Si hay error, recargar reservas y regresar a la vista
            ViewBag.Reservas = await _context.Reservas.ToListAsync();
            var pagos = await _context.Pagos
                .Include(p => p.Reserva)
                .ThenInclude(r => r.Usuario)
                .Include(p => p.Reserva)
                .ThenInclude(r => r.Viaje)
                .ToListAsync();
            return View("~/Views/Crud/Pago.cshtml", pagos);
        }

        // GET: Eliminar pago
        public async Task<IActionResult> Eliminar(int id)
        {
            var pago = await _context.Pagos.FindAsync(id);
            if (pago != null)
            {
                _context.Pagos.Remove(pago);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
