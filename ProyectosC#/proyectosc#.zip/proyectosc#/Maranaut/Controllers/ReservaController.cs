// Archivo: Controllers/ReservaController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Maranaut.Data;
using Maranaut.Models;

namespace Maranaut.Controllers
{
    public class ReservaController : Controller
    {
        private readonly AppDbContext _context;

        public ReservaController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Reserva
        public async Task<IActionResult> Index()
        {
            var reservas = await _context.Reservas
                .Include(r => r.Usuario)
                .Include(r => r.Viaje)
                .ToListAsync();

            // Llenamos los ViewBag para los modales
            ViewBag.Usuarios = _context.Usuarios.ToList();
            ViewBag.Viajes = _context.Viajes.ToList();

            return View("~/Views/Crud/Reserva.cshtml", reservas);
        }

        // POST: Reserva/Crear
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Crear([Bind("FechaReserva,Estado,IdUsuario,IdViaje")] Reserva reserva)
        {
            if (ModelState.IsValid)
            {
                _context.Add(reserva);
                await _context.SaveChangesAsync();
            }
            // Siempre redirigimos a Index que ya llena los ViewBag
            return RedirectToAction(nameof(Index));
        }

        // POST: Reserva/Editar
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Editar(int id, [Bind("IdReserva,FechaReserva,Estado,IdUsuario,IdViaje")] Reserva reserva)
        {
            if (id != reserva.IdReserva) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(reserva);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Reservas.Any(e => e.IdReserva == reserva.IdReserva))
                        return NotFound();
                    else
                        throw;
                }
            }
            // Redirigimos a Index que ya llena los ViewBag
            return RedirectToAction(nameof(Index));
        }

        // GET: Reserva/Eliminar/5
        public async Task<IActionResult> Eliminar(int? id)
        {
            if (id == null) return NotFound();

            var reserva = await _context.Reservas
                .Include(r => r.Usuario)
                .Include(r => r.Viaje)
                .FirstOrDefaultAsync(m => m.IdReserva == id);

            if (reserva == null) return NotFound();

            _context.Reservas.Remove(reserva);
            await _context.SaveChangesAsync();

            // Redirigimos a Index que ya llena los ViewBag
            return RedirectToAction(nameof(Index));
        }
    }
}
