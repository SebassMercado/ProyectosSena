(function () {
  // ====== Referencias ======
  const loginModal = document.getElementById("loginModal");
  const registerModal = document.getElementById("registerModal");
  const forgotModal = document.getElementById("forgotModal");

  // Botones para abrir
  const btnLogin = document.getElementById("btnLogin");
  const btnOpenRegister = document.getElementById("btnOpenRegister");
  const btnBackLogin = document.getElementById("btnBackLogin");
  const btnForgotPassword = document.getElementById("btnForgotPassword");

  // Cierres
  const closeButtons = document.querySelectorAll(".modal .close");

  // ====== Funciones ======
  function openModal(modal) {
    closeAll();
    if (!modal) return;
    modal.style.display = "block";
    document.body.classList.add("modal-open");
    // Foco automático en el primer input del modal
    setTimeout(() => modal.querySelector("input")?.focus(), 0);
  }

  function closeModal(modal) {
    if (!modal) return;
    modal.style.display = "none";
    document.body.classList.remove("modal-open");
  }

  function closeAll() {
    [loginModal, registerModal, forgotModal].forEach(m => {
      if (m) m.style.display = "none";
    });
    document.body.classList.remove("modal-open");
  }

  // ====== Eventos ======
  // Abrir login
  if (btnLogin) btnLogin.addEventListener("click", () => openModal(loginModal));

  // Abrir registro desde login
  if (btnOpenRegister) btnOpenRegister.addEventListener("click", (e) => {
    e.preventDefault();
    openModal(registerModal);
  });

  // Volver al login desde registro
  if (btnBackLogin) btnBackLogin.addEventListener("click", (e) => {
    e.preventDefault();
    openModal(loginModal);
  });

  // Abrir "Olvidé contraseña"
  if (btnForgotPassword) btnForgotPassword.addEventListener("click", (e) => {
    e.preventDefault();
    openModal(forgotModal);
  });

  // Cerrar con X
  closeButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const modal = btn.closest(".modal");
      closeModal(modal);
    });
  });

  // Cerrar al hacer clic fuera del contenido
  window.addEventListener("click", (e) => {
    [loginModal, registerModal, forgotModal].forEach(m => {
      if (e.target === m) closeModal(m);
    });
  });

  // Cerrar con ESC
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeAll();
  });
})();
s