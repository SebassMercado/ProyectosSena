(function () {
  // 1) referencias a DOM
  const modal = document.getElementById("loginModal");
  const openBtn = document.getElementById("btnLogin");
  const closeBtn = modal?.querySelector(".close");
  const form = modal?.querySelector("form");

  // 2) función para abrir modal
  function openModal() {
    if(!modal) return;
    modal.style.display = "block";         // mostrar overlay
    document.body.classList.add("modal-open"); // bloquear scroll del body
    // foco en el username (mejora UX)
    setTimeout(() => modal.querySelector("#username")?.focus(), 0);
  }

  // 3) cerrar modal
  function closeModal() {
    if(!modal) return;
    modal.style.display = "none";
    document.body.classList.remove("modal-open");
  }

  // 4) eventos
  if (openBtn) openBtn.addEventListener("click", openModal); // abrir
  if (closeBtn) closeBtn.addEventListener("click", closeModal); // cerrar con X

  // cerrar al hacer clic fuera (overlay)
  window.addEventListener("click", (e) => {
    if (e.target === modal) closeModal();
  });

  // cerrar con ESC
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modal.style.display === "block") closeModal();
  });

  // 5) interceptar submit para simular login (evitar post real)
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault(); // evita que el navegador haga POST real
      const user = modal.querySelector("#username").value.trim();
      // Aquí puedes: mostrar mensaje, cerrar modal, o redirigir.
      alert(`Login simulado: ${user || "viajero"}`);
      closeModal();
    });
  }
})();