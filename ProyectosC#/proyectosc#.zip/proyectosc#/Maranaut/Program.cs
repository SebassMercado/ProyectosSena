using Maranaut.Data; // 👈 Importa la carpeta Data donde está AppDbContext
using Maranaut.Models; // 👈 Para poder usar Usuario, Viaje, etc.
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// 🚀 Agregar DbContext con MySQL
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        ServerVersion.AutoDetect(builder.Configuration.GetConnectionString("DefaultConnection"))
    )
);

// 🚀 Agregar servicios de sesión
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Tiempo de inactividad
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// 👇 Agregar datos de prueba (solo si la BD está vacía)
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();

    if (!context.Usuarios.Any())
    {
        var usuario = new Usuario
        {
            Nombre = "Sebas",
            Email = "sebas@example.com",
            Contrasena = "1234",
            Rol = "A" // Admin
        };

        var viaje = new Viaje
        {
            Destino = "Cartagena",
            Fecha = DateTime.Now.AddMonths(1),
            Precio = 500000
        };

        var reserva = new Reserva
        {
            Usuario = usuario,
            Viaje = viaje,
            FechaReserva = DateTime.Now,
            Estado = "Confirmada"
        };

        var pago = new Pago
        {
            Reserva = reserva,
            Monto = 500000,
            FechaPago = DateTime.Now,
            MetodoPago = "Tarjeta"
        };

        context.Add(usuario);
        context.Add(viaje);
        context.Add(reserva);
        context.Add(pago);

        context.SaveChanges();
        Console.WriteLine("✅ Datos de prueba insertados en la base de datos.");
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// 🚀 Habilitar sesión (debe ir ANTES de Authorization)
app.UseSession();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
