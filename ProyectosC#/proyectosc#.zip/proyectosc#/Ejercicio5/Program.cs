﻿using System;
using System.Collections.Generic;

namespace Ejercicio4
{
    class Program
    {
        static void Main()
        {
            var s1 = new Sucursal { Direccion = "Sucursal Centro" };
            var s2 = new Sucursal { Direccion = "Sucursal Norte" };

            var clientes = new List<Cliente>();
            var facturas = new List<Factura>();
            var notas = new List<NotaCredito>();

            string[] productos = { "Laptop", "Mouse", "Teclado", "Monitor", "Impresora" };
            double[] precios   = { 500, 25, 40, 150, 200 };

            for (int i = 1; i <= 5; i++)
            {
                var c = new Cliente { Nombre = $"Cliente {i}" };
                clientes.Add(c);

                for (int j = 1; j <= 2; j++)
                {
                    var f = new Factura
                    {
                        Cliente = c,
                        Sucursal = (j % 2 == 0) ? s2 : s1
                    };

                    int nItems = (i + j) % 3 + 1;

                    for (int k = 0; k < nItems; k++)
                    {
                        f.Items.Add(new Item
                        {
                            Descripcion = productos[(i + j + k) % productos.Length],
                            Precio = precios[(i + j + k) % precios.Length],
                            Cantidad = (k % 3) + 1
                        });
                    }

                    c.Documentos.Add(f);
                    f.Sucursal.Documentos.Add(f);
                    facturas.Add(f);
                }
            }

            for (int i = 0; i < 3; i++)
            {
                var fac = facturas[i];
                var nc = new NotaCredito
                {
                    Cliente = fac.Cliente,
                    Sucursal = fac.Sucursal,
                    FacturaOrigen = fac
                };

                var itemDevuelto = fac.Items[0];
                nc.Items.Add(new Item
                {
                    Descripcion = itemDevuelto.Descripcion + " (Devuelto)",
                    Precio = itemDevuelto.Precio,
                    Cantidad = 1
                });

                fac.Cliente.Documentos.Add(nc);
                nc.Sucursal.Documentos.Add(nc);
                notas.Add(nc);
            }

            Console.WriteLine("\n=== FACTURAS ===");
            foreach (var f in facturas) f.Imprimir();

            Console.WriteLine("\n=== NOTAS DE CRÉDITO ===");
            foreach (var n in notas) n.Imprimir();

            Console.WriteLine("\nFin del programa. Presiona ENTER para salir...");
            Console.ReadLine();
        }
    }
}
