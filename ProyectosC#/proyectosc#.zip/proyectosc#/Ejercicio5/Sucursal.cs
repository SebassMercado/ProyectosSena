using System;
using System.Collections.Generic;
namespace Ejercicio4
{
    class Sucursal
    {
        public string Direccion { get; set; }
        public List<Documento> Documentos { get; } = new List<Documento>();
    }

}