using System;
namespace Ejercicio4
{
    class Factura : Documento
    {
        public override void Imprimir()
        {
            Console.WriteLine($"\nFactura #{Numero} - Cliente: {Cliente.Nombre} - Sucursal: {Sucursal.Direccion}");
            foreach (var it in Items)
                Console.WriteLine($"   {it.Descripcion} x{it.Cantidad} = {it.Subtotal()}");
            Console.WriteLine($"Total: {Total()}\n");
        }
    }

}