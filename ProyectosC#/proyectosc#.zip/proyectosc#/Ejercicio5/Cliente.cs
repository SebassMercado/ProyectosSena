using System;
using System.Collections.Generic;
namespace Ejercicio4
{
    class Cliente
    {
        public string Nombre { get; set; }
        public List<Documento> Documentos { get; } = new List<Documento>();
    }
}