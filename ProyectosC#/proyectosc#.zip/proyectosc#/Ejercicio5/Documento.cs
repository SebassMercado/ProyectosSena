using System;
using System.Collections.Generic;
namespace Ejercicio4
{
    abstract class Documento
    {
        private static int consecutivo = 1;
        public int Numero { get; private set; } = consecutivo++;
        public Cliente Cliente { get; set; }
        public Sucursal Sucursal { get; set; }
        public List<Item> Items { get; } = new List<Item>();

        public double Total()
        {
            double t = 0;
            foreach (var i in Items) t += i.Subtotal();
            return t;
        }

        public abstract void Imprimir();
    }

}