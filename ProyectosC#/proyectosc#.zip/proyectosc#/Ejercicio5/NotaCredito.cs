using System;

namespace Ejercicio4
{
    class NotaCredito : Documento
    {
        public Factura FacturaOrigen { get; set; }

        public override void Imprimir()
        {
            Console.WriteLine($"\nNota Crédito #{Numero} (de Factura {FacturaOrigen.Numero}) - Cliente: {Cliente.Nombre}");
            foreach (var it in Items)
                Console.WriteLine($"   {it.Descripcion} x{it.Cantidad} = {it.Subtotal()}");
            Console.WriteLine($"Total NC: {Total()}\n");
        }
    }
}
