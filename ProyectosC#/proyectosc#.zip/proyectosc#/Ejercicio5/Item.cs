using System;
namespace Ejercicio4
{
    class Item
    {
        public string Descripcion { get; set; }
        public double Precio { get; set; }
        public int Cantidad { get; set; }
        public double Subtotal() => Precio * Cantidad;
    }
}
