﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese el nombre del estudiante: ");
        string nombreEstudiante = Console.ReadLine();

        Console.Write("¿Cuántos cursos desea ingresar? ");
        int cantidadCursos = int.Parse(Console.ReadLine());

        string[] cursos = new string[cantidadCursos];
        double[] notas = new double[cantidadCursos]; // Nota del estudiante
        int[] creditos = new int[cantidadCursos];
        int[] horasTotales = new int[cantidadCursos];
        double[] puntosCredito = new double[cantidadCursos];

        int totalCreditos = 0;
        int totalHoras = 0;
        double totalPuntosCredito = 0;
        double sumaNotas = 0;

        for (int i = 0; i < cantidadCursos; i++)
        {
            Console.WriteLine($"\nCurso #{i + 1}:");

            Console.Write("Nombre del curso: ");
            cursos[i] = Console.ReadLine();

            Console.Write("Créditos: ");
            creditos[i] = int.Parse(Console.ReadLine());

            horasTotales[i] = creditos[i] * 12; // Cada crédito equivale a 12 horas
            Console.WriteLine($"Horas totales del curso (12h por crédito): {horasTotales[i]}");

            Console.Write("Nota obtenida (0 a 5): ");
            notas[i] = double.Parse(Console.ReadLine());

            puntosCredito[i] = horasTotales[i] * notas[i];

            totalCreditos += creditos[i];
            totalHoras += horasTotales[i];
            totalPuntosCredito += puntosCredito[i];
            sumaNotas += notas[i];
        }

        Console.WriteLine("____________________________________________________");
        Console.WriteLine($"Estudiante: {nombreEstudiante}");
        Console.WriteLine("____________________________________________________");
        Console.WriteLine("");
        Console.WriteLine("");

        Console.WriteLine($"{"Curso",-22}{"Nota",-10}{"Créditos",-10}{"Horas",-10}{"Puntos"}");
        

        for (int i = 0; i < cantidadCursos; i++)
        {
            Console.WriteLine($"{cursos[i],-22}{notas[i],-10}{creditos[i],-10}{horasTotales[i],-10}{puntosCredito[i]}");
        }

        // Promedio de notas 0-5
        double promedioNotas = sumaNotas / cantidadCursos;

        // Estado según promedio de notas
        string estado = promedioNotas >= 3.5 ? "A" : "D";

        
        Console.WriteLine($"Promedio de Notas (0-5): {promedioNotas:F2}");
        Console.WriteLine($"Estado: {estado}");
    }
}
