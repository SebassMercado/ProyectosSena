﻿using System;
using System.Collections.Generic;
namespace Ejercicio4
{
    class Program
    {
        static void Main()
        {
            // === Crear sucursales (dos fijas) ===
            Console.Write("Dirección Sucursal 1: ");
            var s1 = new Sucursal { Direccion = Console.ReadLine() };
            Console.Write("Dirección Sucursal 2: ");
            var s2 = new Sucursal { Direccion = Console.ReadLine() };

            var clientes = new List<Cliente>();
            var facturas = new List<Factura>();
            var notas = new List<NotaCredito>();

            // === Crear 5 clientes ===
            for (int i = 1; i <= 5; i++)
            {
                Console.Write($"Nombre del Cliente {i}: ");
                var c = new Cliente { Nombre = Console.ReadLine() };
                clientes.Add(c);

                // === Crear 2 facturas por cliente ===
                for (int j = 1; j <= 2; j++)
                {
                    var f = new Factura { Cliente = c, Sucursal = (j % 2 == 0) ? s2 : s1 };
                    Console.WriteLine($"\nFactura {j} para {c.Nombre}:");
                    Console.Write("¿Cuántos ítems tendrá esta factura? (1 a 3): ");
                    int nItems = int.Parse(Console.ReadLine());

                    for (int k = 1; k <= nItems; k++)
                    {
                        Console.Write($"   Descripción del Ítem {k}: ");
                        string desc = Console.ReadLine();
                        Console.Write($"   Precio: ");
                        double precio = double.Parse(Console.ReadLine());
                        Console.Write($"   Cantidad: ");
                        int cant = int.Parse(Console.ReadLine());

                        f.Items.Add(new Item { Descripcion = desc, Precio = precio, Cantidad = cant });
                    }

                    c.Documentos.Add(f);
                    f.Sucursal.Documentos.Add(f);
                    facturas.Add(f);
                }
            }

            // === Crear 3 notas de crédito a partir de facturas ===
            for (int i = 0; i < 3; i++)
            {
                var fac = facturas[i];
                var nc = new NotaCredito { Cliente = fac.Cliente, Sucursal = fac.Sucursal, FacturaOrigen = fac };

                // devolvemos un ítem de esa factura
                var itemDevuelto = fac.Items[0];
                nc.Items.Add(new Item { Descripcion = itemDevuelto.Descripcion + " (Devuelto)", Precio = itemDevuelto.Precio, Cantidad = 1 });

                fac.Cliente.Documentos.Add(nc);
                nc.Sucursal.Documentos.Add(nc);
                notas.Add(nc);
            }

            // === Mostrar resultados ===
            Console.WriteLine("\n=== FACTURAS ===");
            foreach (var f in facturas) f.Imprimir();

            Console.WriteLine("\n=== NOTAS DE CRÉDITO ===");
            foreach (var n in notas) n.Imprimir();

            Console.WriteLine("\nFin del programa. Presiona ENTER para salir...");
            Console.ReadLine();
        }
    }
}